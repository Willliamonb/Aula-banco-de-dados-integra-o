import mysql from "mysql2/promise.js"
import "dotenv/config"

const conexao = await mysql.createConnection({
    host: process.env.DB_ROST,
    user: process.env.DB_USER,
    port: process.env.DB_PORT,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
})

export default conexao