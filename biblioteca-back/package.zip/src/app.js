import "dotenv/config"
import express from "express"
import livrosRouters from "./routes/livrosRotas.js"
import usuariosRotas from "./routes/usuarioRotas.js"

const app = express()

app.use(express.json())


app.use("/livros", livrosRouters)
app.use("/usuarios", usuariosRotas)

// app.use("/livros", livrosRouters)
// app.use("/livros/:id", livrosRouters)
// app.post("/livros", livrosRouters )
// try {
//     console.log("conectando ao banco de dados")

//     const resultado = await conexao.query(
//         "SELECT * FROM livros;"
//     )

//     console.log(resultado)
// } catch (erro) {
//     console.log(erro)
// }


//rota raiz
// app.get("/", (req, res) => {
//     res.send("Api da livraria")
// })


// app.get("/livros", async (req, res) => {
//     try {
//         const [livros] = await conexao.query(
//             "SELECT * FROM livros"
//         )

//         res.json(livros)

//     } catch (erro) {
//         res.status(500).json({
//             erro: erro.mensage
//         })
//     }
// })

// app.get("/livros/:id", async (req, res) => {
//     try {
//         const [resultado] = await conexao.query(
//             "SELECT * FROM livros WHERE id_livro = ?",
//             [req.params.id] //acessar paramentro da url (:id)
//         )

//         if (resultado.length === 0) {
//             return res.status(404).json({
//                 mensagem: "livro não encontrado :("
//             })
//         }
//         res.json(resultado)
//     } catch (erro) {
//         res.status(500).json({
//             erro: erro.mensage
//         })
//     }
// })

// app.post("/livros", async (req, res) => {
//     try {
//         const [titulo_livro, autor_livro, genero_livro] = req.body

//         await conexao.query(
//             "INSERT INTO livros (titulo_livro, autor_livro, genero_livro) VALUES (?, ?, ?)",
//             [titulo_livro, autor_livro, genero_livro]
//         )

//         res.status(201).json({
//             mensagem: "livro cadastrado com sucesso!"
//         })

//     } catch (erro) {
//         res.status(500).json({
//             erro: erro.mensage
//         })
//     }
// })

// app.delete("/livros/:id", async (req, res) => {
//     try {

//         await conexao.query(
//             "DELETE FROM livros WHERE id_livro = ?",
//             [req.params.id]
//         )

//         res.status(200).json({
//             mensagem: "livro apagado!"
//         })

//     } catch (erro) {
//         res.status(500).json({
//             erro: erro.message
//         })
//     }
// })

// app.patch("/livros/:id", async (req, res) => {

//     try {

//         const { titulo_livro, autor_livro, genero_livro } = req.body

//         await conexao.query(
//             "UPDATE livros SET titulo_livro = ?, autor_livro = ?, genero_livro = ? WHERE id_livro = ?",
//             [titulo_livro, autor_livro, genero_livro, req.params.id]
//         )

//         res.status(200).json({
//             mensagem: "livro atualizado!"
//         })

//     } catch (erro) {

//         res.status(500).json({
//             erro: erro.message
//         })

//     }

// })
//------------------------------------------------------------------------

//ativiade 24.08


// rota para puxar usuarios
app.get("/usuarios", async (req, res) => {
    try {
        const [usuarios] = await conexao.query(
            "SELECT * FROM usuarios"
        )
        res.json(usuarios)
    } catch (erro) {
        res.status(500).json({
            erro: erro.mensage
        })
    }
}
)

//rota para puxar com o id
app.get("/usuarios/:id", async (req, res) => {
    try {
        const [validacao] = await conexao.query(
            "SELECT * FROM usuarios WHERE id_user = ?",
            [req.params.id]
        )

        if (validacao.length === 0) {
            return res.status(400).json({
                mensagem: "user não encontrado :("
            })
        }
        res.json(validacao)
    } catch (erro) {
        res.status(500).json({
            erro: erro.mensage
        })
    }

})

//rota para atualizar o usuario pelo id
app.patch("/usuarios/:id", async (req, res) => {
    try {
        const { nome_user, email_user, senha_user } = req.body

        await conexao.query(
            "UPDATE usuarios SET nome_user = ?, email_user = ?, senha_user = ? WHERE id_user = ?",
            [nome_user, email_user, senha_user, req.params.id]
        )


        res.status(200).json({
            mensagem: "user 100% atualizado"
        })

    } catch (erro) {
        res.status(500).json({
            erro: erro.mensage
        })
    }
})

//rota para deletar o usuario
app.delete("/usuarios/:id_user", async (req, res) => {
    try {
        await conexao.query(
            "DELETE FROM usuarios WHERE id_user = ?;",
            [req.params.id_user]
        )

        res.status(200).json({
            mensagem: "user deletado."
        })
    } catch (erro) {
        res.status(500).json({
            erro: erro.mensage
        })
    }
})

//rota que simula um login com o email e com a senha de um id
app.post("/login", async (req, res) => {
    try {

    const {email_user, senha_user} = req.body
        const [usuarios] = await conexao.query(
            "SELECT * FROM usuarios WHERE email_user = ? AND senha_user = ?",
            [email_user, senha_user] 
        )

            if (usuarios.length === 0) {
                return res.status(401).json({
                    mensagem: "email ou senha incoreto"
                })
            } 

            res.status(200).json({
                mensagem: "login realizado com sucesso"
            })
        
} catch(erro) {
    res.status(500).json({
        erro: erro.mensage
    })
}

})


//prof, esse aqui deu errado e não soubemos fazer :(
app.get("/perfil", async (req, res) => {
    try {
          const {nome_user, perfil} = req.body
            await conexao.query(
            "SELECT * FROM usuarios WHERE nome_user = ? AND perfil = ?",
            [nome_user, perfil]
        )
    } catch(erro) {
         res.status(500).json({
        erro: erro.mensage
    })
    }
})















// app.delete("/livros/:id", (req, res) => {
//     const index = buscaLivro(req.params.id)

//     livros.splice(index, 1)

//     res.status(200).send("Livro excluido com sucesso.")
// })


// const livros = [
// {
//     id: 1,
//     titulo: "Harry Potter"
// },
// {
//     id: 2,
//     titulo: "Percy Jackson e os Olimpianos"
// }
// ]

// const buscaLivro = (id) => {
//     return livros.findIndex(livros => {
//         return livros.id === Number(id)
//     })
// }

// app.get("/", (req, res) => {
//     res.status(200).send("UC7 - Backend com Node.js")
// })

// app.get("/livros", (req, res) => {
//     res.status(200).json(livros)
// })

// app.get("/livros/:id", (req, res) => {
//     const index = buscaLivro(req.params.id)

//     res.status(200).json(livros[index])
// })

// app.post("/livros", (req, res) => {
//     livros.push(req.body)

//     res.status(201).send("livro cadastrado com sucesso!")
// })

// app.put("/livros/:id", (req, res) =>{
//     const index = buscaLivro(req.params.id)

//     livros[index].titulo = req.body.titulo

//     res.status(200).json(livros[index])
// })

// app.delete("/livros/:id", (req, res) => {
//     const index = buscaLivro(req.params.id)

//     livros.splice(index, 1)

//     res.status(200).send("Livro excluido com sucesso.")
// })


export default app;
