// FUNÇÕES QUE EXECUTAM O TRABALHO (GET, POST, DELET, PUT, PATCH)
import conexao from "../config/db.js";
import jwt from "jsonwebtoken";

// LISTAR USUÁRIOS
export const listarUsuarios = async (req, res) => {
    try {
        const [usuarios] = await conexao.query(
            "SELECT * FROM usuarios"
        )
 
        res.status(200).json(usuarios);
    } catch (erro) {
        res.status(500).json({
            erro: erro.message
        })
    }
}
 
 
export const buscarUsuario = async (req, res) => {
    try {
        const [usuario] = await conexao.query(
            "SELECT * FROM usuarios WHERE id_usuario = ?",
            [req.params.id]
        );
 
        if (usuario.length === 0) {
            return res.status(404).json({
                mensagem: "Usuário não encontrado"
            })
        }
 
        res.status(200).json(usuario[0]);
    } catch (erro) {
        res.status(500).json({
            erro: erro.message
        })
    }
}
 
 
export const cadastrarUsuario = async (req, res) => {
    try {
        const {nome, email, senha, perfil} = req.body;
 
        await conexao.query(
            `
            INSERT INTO usuarios
            (
                nome,
                email,
                senha,
                perfil
            )
            VALUES (?, ?, ?, ?)
            `,
            [nome, email, senha, perfil]
        )
        res.status(201).json({
            mensagem: "Usuário cadastrado com sucesso!"
        })
 
    } catch (erro) {
        res.status(500).json({
            erro: erro.message
        })
    }
}
 
 
export const atualizarUsuario = async (req, res) => {
    try {
        const {nome, email, senha, perfil} = req.body;
 
        await conexao.query(
            `
            UPDATE usuarios
            SET
                nome = ?,
                email = ?,
                senha = ?,
                perfil = ?
            WHERE id_usuario = ?
            `,
            [
                nome,
                email,
                senha,
                perfil,
                req.params.id
            ]
        )
 
        res.status(200).json({
            mensagem: "Usuário atualizado com sucesso!"
        })
 
    } catch (erro) {
        res.status(500).json({
            erro: erro.message
        })
    }
}
 
 
export const excluirUsuario = async (req, res) => {
 
    try {
        await conexao.query(
            "DELETE FROM usuarios WHERE id_usuario = ?",
            [req.params.id]
        );
 
        res.status(200).json({
            mensagem: "Usuário removido com sucesso!"
        })
 
    } catch (erro) {
 
        res.status(500).json({
            erro: erro.message
        })
    }
}
 
 
export const login = async (req, res) => {
    try {
        const {email, senha} = req.body;
 
        const [usuario] = await conexao.query(
            `
            SELECT *
            FROM usuarios
            WHERE email = ?
            AND senha = ?
            `,
            [
                email,
                senha
            ]
        )
 
        if (usuario.length === 0) {
            return res.status(401).json({
                mensagem: "Usuário ou senha inválidos."
            })
        }
        
        // verificado de token
        const  payLoad = {
            id: usuario[0].id_usuario,
            nome: usuario[0].nome,
            perfil: usuario[0].perfil
        }

        const token = jwt.sign(
            payLoad,
            process.env.jwt_secret,
            {expiresin: process.env.JWT_EXPIRES_IN}
        )

        res.status(200).json({
            mensagem: "Login realizado com sucesso",
            token,
            usuario: payLoad
        })

        // res.status(200).json({
        //     mensagem: "Login realizado com sucesso!",
        //     usuario: {
        //         id: usuario[0].id_usuario,
        //         nome: usuario[0].nome,
        //         perfil: usuario[0].perfil
        //     }
        // })
 
    } catch (erro) {
        res.status(500).json({
            erro: erro.message
        })
    }
}
 