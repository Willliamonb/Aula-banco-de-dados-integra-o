import conexao from "../config/db.js"

export const rotaRaiz = (req, res) => {
    res.send("Api da livraria")
}

export const listarLivros = async (req, res) => {
    try {
        const [livros] = await conexao.query(
            "SELECT * FROM livros"
        )

        res.json(livros)

    } catch (erro) {
        res.status(500).json({
            erro: erro.mensage
        })
    }
}

export const buscarLivro = async (req, res) => {
    try {
        const [resultado] = await conexao.query(
            "SELECT * FROM livros WHERE id_livro = ?",
            [req.params.id] //acessar paramentro da url (:id)
        )

        if (resultado.length === 0) {
            return res.status(404).json({
                mensagem: "livro não encontrado :("
            })
        }
        res.json(resultado)
    } catch (erro) {
        res.status(500).json({
            erro: erro.mensage
        })
    }
}

export const adicionarLivro = async (req, res) => {
    try {
        const { titulo_livro, autor_livro, genero_livro } = req.body

        await conexao.query(
            "INSERT INTO livros (titulo_livro, autor_livro, genero_livro) VALUES (?, ?, ?)",
            [titulo_livro, autor_livro, genero_livro]
        )

        res.status(201).json({
            mensagem: "livro cadastrado com sucesso!"
        })

    } catch (erro) {
        res.status(500).json({
            erro: erro.mensage
        })
    }
}

export const atualizarLivro = async (req, res) => {

    try {

        const { titulo_livro, autor_livro, genero_livro } = req.body

        await conexao.query(
            "UPDATE livros SET titulo_livro = ?, autor_livro = ?, genero_livro = ? WHERE id_livro = ?",
            [titulo_livro, autor_livro, genero_livro, req.params.id]
        )

        res.status(200).json({
            mensagem: "livro atualizado!"
        })

    } catch (erro) {

        res.status(500).json({
            erro: erro.message
        })

    }
}

export const deletarLivro = async (req, res) => {
    try {

        await conexao.query(
            "DELETE FROM livros WHERE id_livro = ?",
            [req.params.id]
        )

        res.status(200).json({
            mensagem: "livro apagado!"
        })

    } catch (erro) {
        res.status(500).json({
            erro: erro.message
        })
    }
}