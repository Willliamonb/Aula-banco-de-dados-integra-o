import { Router } from "express";
import {
  listarUsuarios,
  buscarUsuario,
  cadastrarUsuario,
  atualizarUsuario,
  excluirUsuario,
  login
} from "../controllers/Usuarios.js";

// Importando os middlewares de autenticação e autorização
import autenticar from "../middleware/autentica.js";
import autorizar from "../middleware/autorizar.js";

const router = Router();

// Rota pública para login
router.post("/login", login);

// (Autentica primeiro, Autoriza depois, executa o Controller por último)
router.get("/", autenticar, autorizar("funcionario"), listarUsuarios);
router.get("/:id", autenticar, autorizar("funcionario"), buscarUsuario);
router.post("/", autenticar, autorizar("funcionario"), cadastrarUsuario);
router.put("/:id", autenticar, autorizar("funcionario"), atualizarUsuario);
router.delete("/:id", autenticar, autorizar("funcionario"), excluirUsuario);

export default router;
